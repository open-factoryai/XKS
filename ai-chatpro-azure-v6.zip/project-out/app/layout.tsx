import "./globals.css";

export const metadata = {
  title: "AI ChatPro — Azure Foundry",
  description: "Interface de démonstration Azure OpenAI"
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr" className="dark">
      <body>{children}</body>
    </html>
  );
}
