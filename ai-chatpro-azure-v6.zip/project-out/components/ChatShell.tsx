"use client";

import { useRef, useState, useEffect } from "react";

type Msg = {
  id: string;
  role: "user" | "assistant";
  content: string;
  ts: number;
  latency?: number;
};

function Dot({ active }: { active: boolean }) {
  return (
    <span
      className="inline-block rounded-full"
      style={{
        width: 8,
        height: 8,
        background: active ? "var(--az-green)" : "var(--text-3)",
        boxShadow: active ? "0 0 0 0 rgba(0,200,81,0.5)" : "none",
        animation: active ? "pulse-green 2s ease-in-out infinite" : "none",
        flexShrink: 0,
      }}
    />
  );
}

function Tag({ children, blue }: { children: React.ReactNode; blue?: boolean }) {
  return (
    <span
      style={{
        fontFamily: "var(--mono)",
        fontSize: 11,
        color: blue ? "var(--az-blue)" : "var(--text-2)",
        background: blue ? "var(--az-blue-dim)" : "var(--surface-2)",
        border: `1px solid ${blue ? "var(--border-az)" : "var(--border)"}`,
        borderRadius: 4,
        padding: "2px 8px",
        letterSpacing: "0.02em",
        whiteSpace: "nowrap",
      }}
    >
      {children}
    </span>
  );
}

function StatusBar({ streaming, lastLatency, deployment }: { streaming: boolean; lastLatency?: number; deployment: string }) {
  const [tick, setTick] = useState(0);
  useEffect(() => {
    if (!streaming) return;
    const id = setInterval(() => setTick((t) => t + 1), 100);
    return () => clearInterval(id);
  }, [streaming]);

  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: 12,
        padding: "10px 20px",
        borderBottom: "1px solid var(--border)",
        background: "var(--surface-1)",
        flexWrap: "wrap",
        rowGap: 6,
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginRight: 4 }}>
        <Dot active={!streaming} />
        <span style={{ fontFamily: "var(--mono)", fontSize: 12, color: streaming ? "var(--az-green)" : "var(--text-2)" }}>
          {streaming ? `streaming${".".repeat((tick % 3) + 1)}` : "ready"}
        </span>
      </div>

      <Tag blue>{deployment || "gpt-4o"}</Tag>
      <Tag>Azure AI Foundry</Tag>
      {lastLatency !== undefined && (
        <Tag>{lastLatency}ms</Tag>
      )}

      <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 6 }}>
        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" aria-hidden="true">
          <path d="M9 1.5L16.5 5.25V12.75L9 16.5L1.5 12.75V5.25L9 1.5Z" stroke="#0078D4" strokeWidth="1.2" fill="none"/>
          <path d="M9 5.5L13 7.5V11.5L9 13.5L5 11.5V7.5L9 5.5Z" fill="#0078D4" opacity="0.4"/>
        </svg>
        <span style={{ fontFamily: "var(--mono)", fontSize: 11, color: "var(--az-blue)", letterSpacing: "0.04em" }}>
          Microsoft Azure
        </span>
      </div>
    </div>
  );
}

function UserBubble({ content }: { content: string }) {
  return (
    <div style={{ display: "flex", justifyContent: "flex-end", marginBottom: 16 }}>
      <div
        style={{
          maxWidth: "72%",
          background: "var(--az-blue-dim)",
          border: "1px solid var(--border-az)",
          borderRadius: "16px 16px 4px 16px",
          padding: "12px 16px",
        }}
      >
        <div style={{ fontSize: 11, color: "var(--az-blue)", fontFamily: "var(--mono)", marginBottom: 6, letterSpacing: "0.04em" }}>
          VOUS
        </div>
        <div style={{ fontSize: 15, lineHeight: 1.65, color: "var(--text-1)", whiteSpace: "pre-wrap" }}>
          {content}
        </div>
      </div>
    </div>
  );
}

function AssistantBubble({ content, streaming, latency }: { content: string; streaming?: boolean; latency?: number }) {
  return (
    <div style={{ display: "flex", justifyContent: "flex-start", marginBottom: 16 }}>
      <div style={{ display: "flex", gap: 12, maxWidth: "86%" }}>
        {/* Icône modèle */}
        <div
          style={{
            width: 32,
            height: 32,
            borderRadius: 8,
            background: "var(--surface-2)",
            border: "1px solid var(--border)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            flexShrink: 0,
            marginTop: 2,
          }}
        >
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">
            <circle cx="8" cy="8" r="6" stroke="#0078D4" strokeWidth="1.2"/>
            <circle cx="8" cy="8" r="2.5" fill="#0078D4" opacity="0.6"/>
          </svg>
        </div>

        <div
          style={{
            background: "var(--surface-2)",
            border: "1px solid var(--border)",
            borderRadius: "4px 16px 16px 16px",
            padding: "12px 16px",
            flex: 1,
          }}
        >
          <div style={{ fontSize: 11, color: "var(--text-3)", fontFamily: "var(--mono)", marginBottom: 6, letterSpacing: "0.04em" }}>
            ASSISTANT{latency ? ` · ${latency}ms` : ""}
          </div>
          <div style={{ fontSize: 15, lineHeight: 1.7, color: "var(--text-1)", whiteSpace: "pre-wrap" }}>
            {content || (streaming ? "" : "…")}
            {streaming && (
              <span
                className="cursor-blink"
                style={{
                  display: "inline-block",
                  width: 2,
                  height: 16,
                  background: "var(--az-blue)",
                  marginLeft: 2,
                  verticalAlign: "text-bottom",
                  borderRadius: 1,
                }}
              />
            )}
            {streaming && !content && (
              <span style={{ color: "var(--text-3)", fontFamily: "var(--mono)", fontSize: 13 }}>
                génération en cours…
              </span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

const STARTERS = [
  "Explique-moi l'architecture Azure AI Foundry",
  "Quelles sont les meilleures pratiques pour sécuriser un endpoint Azure OpenAI ?",
  "Comment fonctionne l'authentification via SPN sur Azure ?",
  "Génère un template Terraform pour déployer Azure OpenAI",
];

export default function ChatShell() {
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [streaming, setStreaming] = useState(false);
  const [lastLatency, setLastLatency] = useState<number | undefined>();
  const [deployment] = useState(process.env.NEXT_PUBLIC_DEPLOYMENT || "gpt-4o");
  const bottomRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const abortRef = useRef<AbortController | null>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  async function onSend(text: string) {
    const trimmed = text.trim();
    if (!trimmed || streaming) return;

    const userMsg: Msg = { id: crypto.randomUUID(), role: "user", content: trimmed, ts: Date.now() };
    const assistantId = crypto.randomUUID();
    const assistantMsg: Msg = { id: assistantId, role: "assistant", content: "", ts: Date.now() + 1 };

    setMessages((p) => [...p, userMsg, assistantMsg]);
    setInput("");
    setStreaming(true);

    const t0 = performance.now();
    const abort = new AbortController();
    abortRef.current = abort;
    let firstToken = true;

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: trimmed }),
        signal: abort.signal,
      });

      if (!res.ok || !res.body) {
        const err = await res.text().catch(() => "Erreur inconnue");
        setMessages((p) => p.map((m) => m.id === assistantId ? { ...m, content: `⚠️ ${err}` } : m));
        return;
      }

      const reader = res.body.getReader();
      const dec = new TextDecoder();
      let buf = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buf += dec.decode(value, { stream: true });
        const lines = buf.split("\n");
        buf = lines.pop() ?? "";

        for (const line of lines) {
          const l = line.trim();
          if (!l || l === "data: [DONE]") continue;
          if (l.startsWith("data: ")) {
            try {
              const { token } = JSON.parse(l.slice(6));
              if (token) {
                if (firstToken) {
                  const lat = Math.round(performance.now() - t0);
                  setLastLatency(lat);
                  firstToken = false;
                }
                setMessages((p) => p.map((m) => m.id === assistantId ? { ...m, content: m.content + token } : m));
              }
            } catch { /* ignore */ }
          }
        }
      }

      const total = Math.round(performance.now() - t0);
      setMessages((p) => p.map((m) => m.id === assistantId ? { ...m, latency: total } : m));
      setLastLatency(total);

    } catch (e) {
      if ((e as Error).name !== "AbortError") {
        setMessages((p) => p.map((m) => m.id === assistantId ? { ...m, content: "⚠️ Connexion interrompue." } : m));
      }
    } finally {
      setStreaming(false);
      abortRef.current = null;
      setTimeout(() => textareaRef.current?.focus(), 50);
    }
  }

  const isEmpty = messages.length === 0;

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100dvh", background: "var(--surface-0)" }}>

      {/* ── Top bar ── */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          padding: "14px 20px",
          borderBottom: "1px solid var(--border)",
          background: "var(--surface-1)",
          gap: 12,
          flexShrink: 0,
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          {/* Logo Azure hexagone */}
          <div
            style={{
              width: 36,
              height: 36,
              borderRadius: 8,
              background: "var(--az-blue-dim)",
              border: "1px solid var(--border-az)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden="true">
              <path d="M10 2L18 6.5V13.5L10 18L2 13.5V6.5L10 2Z" stroke="#0078D4" strokeWidth="1.4" fill="rgba(0,120,212,0.15)"/>
              <path d="M10 7L14 9.25V13.75L10 16L6 13.75V9.25L10 7Z" fill="#0078D4" opacity="0.7"/>
            </svg>
          </div>

          <div>
            <div style={{ fontWeight: 600, fontSize: 14, color: "var(--text-1)", letterSpacing: "0.01em" }}>
              AI ChatPro
            </div>
            <div style={{ fontSize: 11, color: "var(--text-3)", fontFamily: "var(--mono)" }}>
              Azure AI Foundry · demo
            </div>
          </div>
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <Dot active />
          <span style={{ fontSize: 12, color: "var(--az-green)", fontFamily: "var(--mono)" }}>live</span>
        </div>
      </div>

      {/* ── Status bar ── */}
      <StatusBar streaming={streaming} lastLatency={lastLatency} deployment={deployment} />

      {/* ── Messages ── */}
      <div style={{ flex: 1, overflowY: "auto", padding: "24px 20px" }}>
        {/* Écran vide */}
        {isEmpty && (
          <div style={{ maxWidth: 560, margin: "60px auto 0", textAlign: "center" }}>
            <div
              style={{
                width: 56,
                height: 56,
                borderRadius: 14,
                background: "var(--az-blue-dim)",
                border: "1px solid var(--border-az)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                margin: "0 auto 20px",
              }}
            >
              <svg width="28" height="28" viewBox="0 0 28 28" fill="none" aria-hidden="true">
                <path d="M14 3L25 9V19L14 25L3 19V9L14 3Z" stroke="#0078D4" strokeWidth="1.5" fill="rgba(0,120,212,0.2)"/>
                <path d="M14 9L20 12.5V19.5L14 23L8 19.5V12.5L14 9Z" fill="#0078D4" opacity="0.5"/>
              </svg>
            </div>
            <h1 style={{ fontSize: 22, fontWeight: 600, color: "var(--text-1)", margin: "0 0 8px" }}>
              Azure AI Foundry
            </h1>
            <p style={{ fontSize: 14, color: "var(--text-2)", margin: "0 0 32px", lineHeight: 1.6 }}>
              Connecté via SPN · Streaming activé · Prêt
            </p>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, textAlign: "left" }}>
              {STARTERS.map((s) => (
                <button
                  key={s}
                  onClick={() => void onSend(s)}
                  style={{
                    background: "var(--surface-2)",
                    border: "1px solid var(--border)",
                    borderRadius: 10,
                    padding: "12px 14px",
                    cursor: "pointer",
                    textAlign: "left",
                    color: "var(--text-2)",
                    fontSize: 13,
                    lineHeight: 1.5,
                    transition: "border-color 0.15s, color 0.15s",
                  }}
                  onMouseEnter={(e) => {
                    (e.currentTarget as HTMLButtonElement).style.borderColor = "var(--border-az)";
                    (e.currentTarget as HTMLButtonElement).style.color = "var(--text-1)";
                  }}
                  onMouseLeave={(e) => {
                    (e.currentTarget as HTMLButtonElement).style.borderColor = "var(--border)";
                    (e.currentTarget as HTMLButtonElement).style.color = "var(--text-2)";
                  }}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Liste des messages */}
        {messages.map((m, i) => {
          const isLastAssistant = m.role === "assistant" && i === messages.length - 1;
          return m.role === "user" ? (
            <UserBubble key={m.id} content={m.content} />
          ) : (
            <AssistantBubble
              key={m.id}
              content={m.content}
              streaming={streaming && isLastAssistant}
              latency={m.latency}
            />
          );
        })}

        <div ref={bottomRef} />
      </div>

      {/* ── Composer ── */}
      <div
        style={{
          borderTop: "1px solid var(--border)",
          background: "var(--surface-1)",
          padding: "14px 16px",
          flexShrink: 0,
        }}
      >
        <div
          style={{
            display: "flex",
            alignItems: "flex-end",
            gap: 10,
            background: "var(--surface-2)",
            border: `1px solid ${streaming ? "var(--border-az)" : "var(--border)"}`,
            borderRadius: 12,
            padding: "10px 12px",
            transition: "border-color 0.2s",
          }}
        >
          <textarea
            ref={textareaRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                void onSend(input);
              }
            }}
            disabled={streaming}
            rows={1}
            placeholder={streaming ? "Génération en cours…" : "Posez votre question…"}
            style={{
              flex: 1,
              background: "transparent",
              border: "none",
              outline: "none",
              color: "var(--text-1)",
              fontSize: 14,
              lineHeight: 1.6,
              resize: "none",
              fontFamily: "inherit",
              opacity: streaming ? 0.5 : 1,
              minHeight: 22,
            }}
          />

          <button
            onClick={() => void onSend(input)}
            disabled={streaming || !input.trim()}
            style={{
              width: 34,
              height: 34,
              borderRadius: 8,
              background: streaming || !input.trim() ? "var(--surface-3)" : "var(--az-blue)",
              border: "none",
              cursor: streaming || !input.trim() ? "not-allowed" : "pointer",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              flexShrink: 0,
              transition: "background 0.15s",
            }}
            aria-label="Envoyer"
          >
            {streaming ? (
              /* Loader 3 dots */
              <svg width="16" height="8" viewBox="0 0 16 8" fill="none" aria-hidden="true">
                {[0, 6, 12].map((x, i) => (
                  <circle key={i} cx={x + 2} cy="4" r="2" fill="var(--az-blue)" opacity={0.4}>
                    <animate attributeName="opacity" values="0.4;1;0.4" dur="1s" begin={`${i * 0.25}s`} repeatCount="indefinite"/>
                  </circle>
                ))}
              </svg>
            ) : (
              <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden="true">
                <path d="M7 12V2M2 7l5-5 5 5" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            )}
          </button>
        </div>

        <div style={{ textAlign: "center", marginTop: 8, fontSize: 11, color: "var(--text-3)", fontFamily: "var(--mono)" }}>
          ↵ envoyer · ⇧↵ nouvelle ligne
        </div>
      </div>
    </div>
  );
}
