# AI ChatPro — Azure AI Foundry

## Setup

```bash
cp .env.example .env
# → remplir les valeurs dans .env
```

> Le SPN doit avoir le rôle **Cognitive Services OpenAI User** sur la ressource Azure OpenAI.

---

## Lancer en local (Node)

```bash
npm install
npm run dev
# http://localhost:3000
```

---

## Lancer avec Docker

```bash
# Build + run (lit automatiquement le fichier .env)
docker compose up --build

# Ou sans compose :
docker build -t ai-chatpro .
docker run --env-file .env -p 3000:3000 ai-chatpro
```

---

## Variables d'environnement

| Variable | Description |
|---|---|
| `AZURE_TENANT_ID` | ID du tenant Azure AD |
| `AZURE_CLIENT_ID` | Client ID du SPN |
| `AZURE_CLIENT_SECRET` | Secret du SPN |
| `AZURE_SUBSCRIPTION_ID` | ID de la subscription |
| `AZURE_RESOURCE_GROUP` | Nom du resource group |
| `AZURE_OPENAI_ENDPOINT` | URL de la ressource (`https://<nom>.openai.azure.com`) |
| `AZURE_OPENAI_DEPLOYMENT` | Nom du déploiement dans Foundry |
| `AZURE_OPENAI_API_VERSION` | Version API (défaut : `2024-02-01`) |
| `NEXT_PUBLIC_DEPLOYMENT` | Nom affiché dans la status bar (= `AZURE_OPENAI_DEPLOYMENT`) |
