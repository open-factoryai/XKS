/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: ['class'],
  content: [
    './app/**/*.{js,ts,jsx,tsx}',
    './components/**/*.{js,ts,ts,tsx}',
    './pages/**/*.{js,ts,jsx,tsx}'
  ],
  theme: {
    extend: {
      boxShadow: {
        glow: '0 0 30px rgba(124,58,237,.35)'
      },
      backgroundImage: {
        'glass-radial': 'radial-gradient(1200px circle at 20% 0%, rgba(124,58,237,.25), transparent 60%), radial-gradient(900px circle at 90% 10%, rgba(59,130,246,.18), transparent 55%)'
      }
    }
  },
  plugins: []
};
