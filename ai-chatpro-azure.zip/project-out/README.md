# AI ChatPro — UI Mobile

Application Next.js mobile-first avec chat en streaming vers Azure AI Foundry (OpenAI), authentifiée via SPN.

---

## Configuration

Copie le fichier d'exemple et remplis les valeurs :

```bash
cp .env.example .env.local
```

| Variable | Description |
|---|---|
| `AZURE_TENANT_ID` | ID du tenant Azure AD |
| `AZURE_CLIENT_ID` | Client ID du SPN |
| `AZURE_CLIENT_SECRET` | Secret du SPN |
| `AZURE_SUBSCRIPTION_ID` | ID de la subscription |
| `AZURE_RESOURCE_GROUP` | Nom du resource group |
| `AZURE_OPENAI_ENDPOINT` | URL de la ressource Azure OpenAI (ex: `https://xxx.openai.azure.com`) |
| `AZURE_OPENAI_DEPLOYMENT` | Nom du déploiement dans Foundry |
| `AZURE_OPENAI_API_VERSION` | Version API (défaut: `2024-02-01`) |

> Le SPN doit avoir le rôle **Cognitive Services OpenAI User** sur la ressource Azure OpenAI.

---

## Développement local

```bash
npm install
npm run dev
```

## Docker

```bash
# Build
docker build -t ai-chatpro .

# Run (charge le .env.local)
docker run --env-file .env.local -p 3000:3000 ai-chatpro
```

Ouvre http://localhost:3000

---

## Architecture

```
POST /api/chat
  └─ Échange client_credentials → token Azure AD
  └─ Appel streaming Azure OpenAI (SSE)
  └─ Relay token par token vers le navigateur
```

Le message utilisateur s'affiche immédiatement, puis la réponse s'écrit en temps réel avec un curseur clignotant.
