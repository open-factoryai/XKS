"use client";

type Tab = "home" | "help" | "cloud";

export default function Sidebar({
  activeTab,
  onChangeTab
}: {
  activeTab: Tab;
  onChangeTab: (t: Tab) => void;
}) {
  const items: { key: Tab; label: string; icon: string }[] = [
    { key: "home", label: "Mes chats", icon: "💬" },
    { key: "help", label: "Centre d’aide", icon: "❓" },
    { key: "cloud", label: "Mon cloud", icon: "☁️" }
  ];

  return (
    <aside className="rounded-3xl border border-white/10 bg-white/5 p-3">
      <div className="text-xs uppercase tracking-wider text-zinc-400 px-2 py-1">Navigation</div>
      <div className="mt-2 space-y-2">
        {items.map((it) => (
          <button
            key={it.key}
            onClick={() => onChangeTab(it.key)}
            className={[
              "w-full flex items-center gap-3 rounded-2xl px-3 py-2 border transition",
              activeTab === it.key
                ? "bg-white/10 border-white/20"
                : "bg-transparent border-white/10 hover:bg-white/10"
            ].join(" ")}
          >
            <span className="text-lg">{it.icon}</span>
            <span className="text-sm font-medium">{it.label}</span>
          </button>
        ))}
      </div>

      <div className="mt-4 rounded-2xl border border-white/10 bg-gradient-to-r from-fuchsia-500/15 to-cyan-500/15 p-3">
        <div className="text-sm font-semibold">Go Pro</div>
        <div className="text-xs text-zinc-300 mt-1">Débloque des limites plus élevées et des options avancées.</div>
        <button className="mt-3 w-full rounded-2xl bg-gradient-to-r from-fuchsia-500 to-cyan-500 px-3 py-2 text-xs font-semibold">
          Passer en PRO
        </button>
      </div>
    </aside>
  );
}
