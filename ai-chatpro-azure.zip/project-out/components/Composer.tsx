"use client";

import { useRef } from "react";
import { motion } from "framer-motion";

export default function Composer({
  input,
  setInput,
  onSend,
  disabled
}: {
  input: string;
  setInput: (v: string) => void;
  onSend: (text: string) => void | Promise<void>;
  disabled?: boolean;
}) {
  const ref = useRef<HTMLTextAreaElement | null>(null);

  async function handleSubmit() {
    if (disabled) return;
    const v = input.trim();
    if (!v) return;
    await onSend(v);
    ref.current?.focus();
  }

  return (
    <div className="p-3 sm:p-4 border-t border-white/10">
      <div className="rounded-3xl border border-white/10 bg-black/35 backdrop-blur-xl p-2 sm:p-2 flex items-end gap-2">
        <button
          className="h-10 w-10 rounded-2xl bg-white/5 border border-white/10 grid place-items-center hover:bg-white/10 transition disabled:opacity-40"
          type="button"
          disabled={disabled}
          aria-label="Enregistrement (mock)"
          onClick={() => {
            setInput((prev) => (prev ? prev : "Dis-moi ce que tu sais sur ..."));
            ref.current?.focus();
          }}
        >
          🎙️
        </button>

        <div className="flex-1">
          <textarea
            ref={ref}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            rows={1}
            disabled={disabled}
            placeholder={disabled ? "L'assistant répond…" : "Comment puis-je vous aider ?"}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                void handleSubmit();
              }
            }}
            className="w-full resize-none bg-transparent outline-none text-sm sm:text-[15px] placeholder:text-zinc-500 py-2 px-2 disabled:opacity-50"
          />
          <div className="text-[11px] text-zinc-500 px-2 pb-1">
            Entrée pour envoyer • Maj+Entrée pour aller à la ligne
          </div>
        </div>

        <motion.button
          whileHover={disabled ? {} : { scale: 1.02 }}
          whileTap={disabled ? {} : { scale: 0.98 }}
          onClick={() => void handleSubmit()}
          disabled={disabled}
          className="h-10 rounded-2xl px-3 bg-gradient-to-r from-fuchsia-500 to-cyan-500 text-sm font-semibold disabled:opacity-60 disabled:cursor-not-allowed border border-white/10"
        >
          {disabled ? (
            <span className="flex items-center gap-1.5">
              <span className="h-1.5 w-1.5 rounded-full bg-white animate-bounce [animation-delay:0ms]" />
              <span className="h-1.5 w-1.5 rounded-full bg-white animate-bounce [animation-delay:150ms]" />
              <span className="h-1.5 w-1.5 rounded-full bg-white animate-bounce [animation-delay:300ms]" />
            </span>
          ) : (
            "Envoyer"
          )}
        </motion.button>
      </div>
    </div>
  );
}
