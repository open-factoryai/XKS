"use client";

import { useMemo, useRef, useState } from "react";
import ChatHeader from "./ChatHeader";
import Sidebar from "./Sidebar";
import MessageList from "./MessageList";
import Composer from "./Composer";
import MobileDrawer from "./MobileDrawer";

type Msg = { id: string; role: "user" | "assistant"; content: string; ts: number };

export default function ChatShell() {
  const [activeTab, setActiveTab] = useState<"home" | "help" | "cloud">("home");
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [messages, setMessages] = useState<Msg[]>([
    { id: "m1", role: "assistant", content: "Comment puis-je vous aider ?", ts: Date.now() - 120000 },
    { id: "m2", role: "assistant", content: "Posez vos questions, créez du contenu, analysez vos documents.", ts: Date.now() - 70000 }
  ]);
  const [input, setInput] = useState("");
  const [streaming, setStreaming] = useState(false);
  const abortRef = useRef<AbortController | null>(null);

  const quickActions = useMemo(
    () => [
      { label: "Crée-moi une image de ...", prompt: "Crée-moi une image de ..." },
      { label: "Traduis-moi le texte suivant ...", prompt: "Traduis-moi le texte suivant ..." },
      { label: "Dis-moi ce que tu sais sur ...", prompt: "Dis-moi ce que tu sais sur ..." },
      { label: "Apprends-moi à ...", prompt: "Apprends-moi à ..." }
    ],
    []
  );

  async function onSend(text: string) {
    const trimmed = text.trim();
    if (!trimmed || streaming) return;

    // 1 — Affiche immédiatement le message utilisateur
    const userMsg: Msg = { id: crypto.randomUUID(), role: "user", content: trimmed, ts: Date.now() };
    setMessages((prev) => [...prev, userMsg]);
    setInput("");

    // 2 — Ajoute un message assistant vide (sera rempli token par token)
    const assistantId = crypto.randomUUID();
    const assistantMsg: Msg = { id: assistantId, role: "assistant", content: "", ts: Date.now() + 1 };
    setMessages((prev) => [...prev, assistantMsg]);
    setStreaming(true);

    const abort = new AbortController();
    abortRef.current = abort;

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: trimmed }),
        signal: abort.signal,
      });

      if (!res.ok || !res.body) {
        const err = await res.text().catch(() => "Erreur inconnue");
        setMessages((prev) =>
          prev.map((m) =>
            m.id === assistantId ? { ...m, content: `⚠️ Erreur : ${err}` } : m
          )
        );
        return;
      }

      // 3 — Lit le stream SSE token par token
      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() ?? "";

        for (const line of lines) {
          const trimmedLine = line.trim();
          if (!trimmedLine || trimmedLine === "data: [DONE]") continue;
          if (trimmedLine.startsWith("data: ")) {
            try {
              const json = JSON.parse(trimmedLine.slice(6));
              const token: string = json?.token ?? "";
              if (token) {
                setMessages((prev) =>
                  prev.map((m) =>
                    m.id === assistantId ? { ...m, content: m.content + token } : m
                  )
                );
              }
            } catch {
              // ignore
            }
          }
        }
      }
    } catch (e) {
      if ((e as Error).name !== "AbortError") {
        setMessages((prev) =>
          prev.map((m) =>
            m.id === assistantId
              ? { ...m, content: "⚠️ Connexion interrompue. Réessaie dans quelques secondes." }
              : m
          )
        );
      }
    } finally {
      setStreaming(false);
      abortRef.current = null;
    }
  }

  return (
    <div className="min-h-dvh w-full">
      <div className="mx-auto max-w-7xl px-3 sm:px-4 py-3 sm:py-5">
        <ChatHeader
          activeTab={activeTab}
          onChangeTab={setActiveTab}
          credits={0}
          brand="AI-Chatpro"
          onOpenDrawer={() => setDrawerOpen(true)}
        />

        <div className="mt-3 sm:mt-4 grid grid-cols-12 gap-3 sm:gap-4">
          <div className="col-span-12 sm:col-span-3 lg:col-span-3 hidden sm:block">
            <Sidebar activeTab={activeTab} onChangeTab={setActiveTab} />
          </div>

          <main className="col-span-12 sm:col-span-9 lg:col-span-9">
            <div className="relative overflow-hidden rounded-3xl border border-white/10 bg-black/35 backdrop-blur-xl shadow-[0_0_0_1px_rgba(255,255,255,.03),0_20px_60px_rgba(0,0,0,.4)]">
              <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(700px_circle_at_10%_0%,rgba(124,58,237,.35),transparent_55%),radial-gradient(650px_circle_at_80%_10%,rgba(59,130,246,.22),transparent_60%)] opacity-70" />
              <div className="relative">
                <div className="flex items-center justify-between p-4 sm:p-5 border-b border-white/10">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-2xl bg-white/5 border border-white/10 grid place-items-center shadow-glow">
                      <span className="text-lg">💬</span>
                    </div>
                    <div>
                      <h2 className="font-semibold text-base sm:text-lg">Nouveau chat</h2>
                      <p className="text-xs sm:text-sm text-zinc-300">
                        {streaming ? (
                          <span className="flex items-center gap-1.5">
                            <span className="inline-flex gap-0.5">
                              <span className="h-1.5 w-1.5 rounded-full bg-fuchsia-400 animate-bounce [animation-delay:0ms]" />
                              <span className="h-1.5 w-1.5 rounded-full bg-fuchsia-400 animate-bounce [animation-delay:150ms]" />
                              <span className="h-1.5 w-1.5 rounded-full bg-fuchsia-400 animate-bounce [animation-delay:300ms]" />
                            </span>
                            L'assistant répond…
                          </span>
                        ) : (
                          "Vos chats apparaîtrons ici"
                        )}
                      </p>
                    </div>
                  </div>

                  <div className="hidden sm:flex items-center gap-2">
                    <span className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs text-zinc-200">
                      <span className="h-2 w-2 rounded-full bg-emerald-400 shadow-[0_0_18px_rgba(52,211,153,.8)]" />
                      Online
                    </span>
                    <span className="rounded-full bg-gradient-to-r from-fuchsia-500 to-cyan-500 px-3 py-1.5 text-xs font-semibold">
                      PRO
                    </span>
                  </div>
                </div>

                <MessageList messages={messages} streaming={streaming} />

                <div className="p-3 sm:p-4 border-t border-white/10">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {quickActions.map((qa) => (
                      <button
                        key={qa.label}
                        onClick={() => void onSend(qa.prompt)}
                        disabled={streaming}
                        className="text-left rounded-2xl border border-white/10 bg-white/5 hover:bg-white/10 transition p-3 disabled:opacity-40 disabled:cursor-not-allowed"
                      >
                        <div className="text-sm font-medium">{qa.label}</div>
                        <div className="text-[11px] text-zinc-400 mt-1">Tap pour envoyer</div>
                      </button>
                    ))}
                  </div>
                </div>

                <Composer input={input} setInput={setInput} onSend={onSend} disabled={streaming} />
              </div>
            </div>
          </main>
        </div>
      </div>

      <MobileDrawer open={drawerOpen} onClose={() => setDrawerOpen(false)}>
        <Sidebar
          activeTab={activeTab}
          onChangeTab={(t) => {
            setActiveTab(t);
            setDrawerOpen(false);
          }}
        />
      </MobileDrawer>
    </div>
  );
}
