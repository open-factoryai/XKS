"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";

type Tab = "home" | "help" | "cloud";

export default function ChatHeader({
  activeTab,
  onChangeTab,
  credits,
  brand,
  onOpenDrawer
}: {
  activeTab: Tab;
  onChangeTab: (t: Tab) => void;
  credits: number;
  brand: string;
  onOpenDrawer: () => void;
}) {
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const tabBtn = (t: Tab, label: string) => (
    <button
      key={t}
      onClick={() => onChangeTab(t)}
      className={[
        "px-3 py-1.5 rounded-full text-xs border transition",
        activeTab === t
          ? "bg-white/10 border-white/20"
          : "border-white/10 bg-white/5 hover:bg-white/10"
      ].join(" ")}
    >
      {label}
    </button>
  );

  return (
    <header className={[
      "flex items-center justify-between gap-3 sticky top-0 z-20",
      scrolled ? "backdrop-blur-xl bg-black/30 border-b border-white/10" : ""
    ].join(" ")}>
      <div className="flex items-center gap-3">
        <button
          className="sm:hidden h-11 w-11 rounded-2xl bg-white/5 border border-white/10 grid place-items-center"
          onClick={onOpenDrawer}
          aria-label="Ouvrir le menu"
        >
          ☰
        </button>

        <div className="h-11 w-11 rounded-2xl bg-white/5 border border-white/10 grid place-items-center shadow">
          <span className="text-lg">⚡</span>
        </div>

        <div className="hidden sm:block">
          <div className="font-semibold text-sm sm:text-base">{brand}</div>
          <div className="text-[11px] text-zinc-400">Chat • Images • Traduction • Analyse</div>
        </div>

        <div className="sm:hidden">
          <div className="font-semibold text-sm">{brand}</div>
          <div className="text-[11px] text-zinc-400">Chat premium</div>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <div className="hidden sm:flex items-center gap-2">
          {tabBtn("home", "Mes chats")}
          {tabBtn("help", "Centre d’aide")}
          {tabBtn("cloud", "Mon cloud")}
        </div>

        <div className="hidden sm:flex items-center gap-2">
          <span className="rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs text-zinc-200">
            <span className="text-zinc-400">Crédits:</span> {credits}
          </span>
          <button className="rounded-full bg-gradient-to-r from-fuchsia-500 to-cyan-500 px-3 py-1.5 text-xs font-semibold">
            Se connecter
          </button>
        </div>

        <div className="sm:hidden">
          <span className="rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs text-zinc-200">
            {credits} crédits
          </span>
        </div>
      </div>
    </header>
  );
}
