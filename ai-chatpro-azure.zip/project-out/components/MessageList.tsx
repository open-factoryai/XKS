"use client";

import { useEffect, useRef } from "react";
import { motion } from "framer-motion";

type Msg = { id: string; role: "user" | "assistant"; content: string };

export default function MessageList({
  messages,
  streaming
}: {
  messages: Msg[];
  streaming?: boolean;
}) {
  const bottomRef = useRef<HTMLDivElement | null>(null);

  // Auto-scroll vers le bas à chaque nouveau token
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const lastAssistantIdx = [...messages].reverse().findIndex((m) => m.role === "assistant");
  const lastAssistantId =
    lastAssistantIdx !== -1 ? messages[messages.length - 1 - lastAssistantIdx].id : null;

  return (
    <div className="p-3 sm:p-4" style={{ maxHeight: "55vh", overflow: "auto" }}>
      <div className="space-y-3">
        {messages.map((m) => {
          const isUser = m.role === "user";
          const isStreamingThis = streaming && m.id === lastAssistantId;

          return (
            <motion.div
              key={m.id}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.2 }}
              className={`flex ${isUser ? "justify-end" : "justify-start"}`}
            >
              <div
                className={[
                  "max-w-[92%] sm:max-w-[80%] rounded-3xl border p-3 sm:p-4",
                  isUser
                    ? "bg-gradient-to-r from-fuchsia-500/20 to-cyan-500/15 border-white/15"
                    : "bg-white/5 border-white/10"
                ].join(" ")}
              >
                <div className="text-[11px] text-zinc-400 mb-2">{isUser ? "Vous" : "Assistant"}</div>
                <div className="text-sm sm:text-[15px] leading-relaxed whitespace-pre-wrap">
                  {m.content || (isStreamingThis ? null : null)}
                  {/* Curseur clignotant pendant le streaming */}
                  {isStreamingThis && (
                    <span className="inline-block w-0.5 h-4 bg-fuchsia-400 ml-0.5 animate-pulse align-middle" />
                  )}
                  {/* Indicateur "en train de répondre" si le contenu est encore vide */}
                  {isStreamingThis && !m.content && (
                    <span className="text-zinc-500 italic text-xs">En train de répondre…</span>
                  )}
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
      <div ref={bottomRef} />
    </div>
  );
}
