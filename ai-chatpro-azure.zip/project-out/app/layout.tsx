import "./globals.css";

export const metadata = {
  title: "AI ChatPro (Mobile UI)",
  description: "UI mobile moderne inspirée d'un chat premium"
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr" className="dark">
      <body className="min-h-dvh bg-glass-radial bg-[radial-gradient(1200px_circle_at_20%_0%,rgba(124,58,237,.25),transparent_60%),radial-gradient(900px_circle_at_90%_10%,rgba(59,130,246,.18),transparent_55%)] text-zinc-100">
        {children}
      </body>
    </html>
  );
}
