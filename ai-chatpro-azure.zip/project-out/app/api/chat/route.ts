import { NextRequest } from "next/server";

// ── Récupère un token OAuth2 via le SPN (client_credentials) ──────────────────
async function getAzureToken(): Promise<string> {
  const tenantId = process.env.AZURE_TENANT_ID!;
  const clientId = process.env.AZURE_CLIENT_ID!;
  const clientSecret = process.env.AZURE_CLIENT_SECRET!;

  const url = `https://login.microsoftonline.com/${tenantId}/oauth2/v2.0/token`;

  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "client_credentials",
      client_id: clientId,
      client_secret: clientSecret,
      scope: "https://cognitiveservices.azure.com/.default",
    }),
  });

  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Token SPN failed: ${err}`);
  }

  const json = await res.json();
  return json.access_token as string;
}

// ── Handler POST — streaming SSE vers le client ────────────────────────────────
export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const message = String(body?.message ?? "").trim();

  if (!message) {
    return new Response(JSON.stringify({ error: "Message vide" }), { status: 400 });
  }

  const endpoint = process.env.AZURE_OPENAI_ENDPOINT!;
  const deployment = process.env.AZURE_OPENAI_DEPLOYMENT!;
  const apiVersion = process.env.AZURE_OPENAI_API_VERSION ?? "2024-02-01";

  let token: string;
  try {
    token = await getAzureToken();
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e) }), { status: 500 });
  }

  const azureUrl = `${endpoint}/openai/deployments/${deployment}/chat/completions?api-version=${apiVersion}`;

  const azureRes = await fetch(azureUrl, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({
      messages: [{ role: "user", content: message }],
      stream: true,
      max_tokens: 1024,
    }),
  });

  if (!azureRes.ok || !azureRes.body) {
    const err = await azureRes.text();
    return new Response(JSON.stringify({ error: err }), { status: azureRes.status });
  }

  // Relay du stream SSE d'Azure vers le client
  const encoder = new TextEncoder();
  const stream = new ReadableStream({
    async start(controller) {
      const reader = azureRes.body!.getReader();
      const decoder = new TextDecoder();
      let buffer = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() ?? "";

        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed || trimmed === "data: [DONE]") continue;
          if (trimmed.startsWith("data: ")) {
            try {
              const json = JSON.parse(trimmed.slice(6));
              const delta = json?.choices?.[0]?.delta?.content;
              if (delta) {
                // Envoie chaque token au client sous forme SSE
                controller.enqueue(encoder.encode(`data: ${JSON.stringify({ token: delta })}\n\n`));
              }
            } catch {
              // ligne malformée — on ignore
            }
          }
        }
      }

      controller.enqueue(encoder.encode("data: [DONE]\n\n"));
      controller.close();
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
    },
  });
}
